
const Activity = () => {
    return (
        <div>Activity is here</div>
    )
}

export default Activity