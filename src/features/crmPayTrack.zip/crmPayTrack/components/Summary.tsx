import { runApiWithLoader } from "@/core/utils";
import React, { useEffect, useState } from "react";
import { bookingService } from '@/features/booking/services/BookingService';
import type { BookingData, FilterWithPaginationBookingRequest } from '@/features/booking/models/BookingModel';
import { useToast } from '@/core/hooks/useToast';
import { Loader } from '@/core/utils/loader';
import * as E from 'fp-ts/Either';
import { useProject } from '@/features/projectMaster/context/ProjectContext';
import { usePayTrackBookingListState } from "../context/PayTrackBookingListStateContext";
import { FieldItem } from "@/ui/components/forms/FieldItem";
import { getSafeString } from '@/core/utils/comman';
import NoDataView from '@/ui/components/NoDataView/NoDataView';

export const Summary: React.FC = () => {

    const [bookingData, setBookingData] = useState<BookingData | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [loadingMessage, setLoadingMessage] = useState('');
    const { addToast } = useToast();

    const { projectId } = useProject();
    const { listState } = usePayTrackBookingListState();
    const { bookingId } = listState;

    const applicantData = bookingData?.BookingApplicantData?.filter(
        (item) => item.ApplicantType === 'Applicant'
    );

    //#region INIT
    useEffect(() => {
        if (!projectId || !bookingId) return;

        loadBookingForSummary();

    }, [projectId, bookingId]);
    //#endregion

    const loadBookingForSummary = async () => {
        if (!bookingId) return;
        await runApiWithLoader(
            setIsLoading,
            setLoadingMessage,
            async () => {

                const params: FilterWithPaginationBookingRequest = {
                    PageNumber: 1,
                    PageSize: 1,
                    BookingId: bookingId,
                    ProjectId: Number(projectId),
                    IsCheckPermission: false
                };

                const response = await bookingService.apiCallPullBooking(params);

                if (E.isRight(response)) {
                    const booking = response.right.Data?.[0] ?? null;

                    setBookingData(booking);

                } else {
                    addToast({ type: 'error', title: response.left.message });
                }

                return response;
            },
            undefined,
            (error: any) => {
                addToast({ type: 'error', title: error.message });
            },
            undefined,
            'Loading Booking Data'
        );
    };

    return (
        <div>
            <Loader loading={isLoading} title={loadingMessage}>
                <div></div>
            </Loader>

            {/* =================Applicant Details ================= */}
            <section className="bg-white rounded-xl pt-5">
                <h4 className="text-lg font-semibold text-gray-900 mb-4 ">
                    Applicant Details
                </h4>
                {applicantData && applicantData.length > 0 ? (
                    <div className="space-y-4">
                        {applicantData.map((applicant, i) => (
                            <div key={applicant.BookingApplicantId ?? i} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                                    <FieldItem label="Name" value={getSafeString(applicant.ApplicantName)} urls={applicant?.PhotoURL} isIcon />
                                    <FieldItem label="Mobile Number" value={getSafeString(applicant?.ApplicantMobileNumber)} />
                                    <FieldItem label="Email Id" value={getSafeString(applicant?.ApplicantEmailId)} />
                                    <FieldItem label="Aadhar Card" value={getSafeString(applicant?.AadharCardNumber)} urls={applicant?.AadharCardURL} isIcon />
                                    <FieldItem label="Pan Card" value={getSafeString(applicant?.PanNumber)} urls={applicant?.PanCardURL} isIcon />
                                    <FieldItem label="Voting Id" value={getSafeString(applicant?.VotingIdNumber)} urls={applicant?.VotingIdURL} isIcon />
                                    <FieldItem label="Passport" value={getSafeString(applicant?.PassportNumber)} urls={applicant?.PassportURL} isIcon />
                                    <FieldItem label="Driving License" value={getSafeString(applicant?.DrivingLicenseNumber)} urls={applicant?.DrivingLicenseURL} isIcon />
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="py-6 text-center text-gray-500 text-sm bg-gray-50 rounded-lg border border-gray-200">
                        <NoDataView message="No Applicant Data Found" />
                    </div>
                )}
            </section>

            {/* =================Parking Details ================= */}
            <section className="bg-white rounded-xl pt-5">
                <h4 className="text-lg font-semibold text-gray-900 mb-4 ">
                    Parking Details
                </h4>
                {bookingData?.ParkingData && bookingData.ParkingData.length > 0 ? (
                    <div className="space-y-4">
                        {bookingData.ParkingData.map((parking, index) => (
                            <div key={parking.ParkingId || index} className="bg-gray-50 rounded-lg p-4 border border-gray-200">

                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                                    <FieldItem label="Parking Number" value={getSafeString(parking.ParkingNumber)} />
                                    <FieldItem label="Category" value={getSafeString(parking.ParkingCategory)} />
                                    <FieldItem label="Type" value={getSafeString(parking.ParkingType)} />
                                    <FieldItem label="Size" value={getSafeString(parking.ParkingSubType)} />
                                    <FieldItem label="Dimensions" value={getSafeString(parking.ParkingDimensions)} />
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="py-6 text-center text-gray-500 text-sm bg-gray-50 rounded-lg border border-gray-200">
                        <NoDataView message="No Parking Data Found" />
                    </div>
                )}
            </section>

            {/* =================Flat Specification Remark ================= */}
            <div className="col-span-7 pt-5">
                <h4 className="text-lg font-semibold text-gray-900 pb-2">Flat Specification Remark</h4>
                <div className="bg-white rounded-lg border border-gray-300 shadow-sm p-4">
                    <div className="lg:col-span-3 pt-1">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 gap-4">
                            <FieldItem label="" value={bookingData?.FlatAlterationRemark || "-"} />
                        </div>
                    </div>
                </div>
            </div>

        </div>
    )
}

export default Summary